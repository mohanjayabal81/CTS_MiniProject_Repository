package tests;

import browsers.BrowserImplementations;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import config.ObjectReader;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.AccountCreationPage;
import pages.LandingPage;
import utility.TestUtilities;

import java.io.IOException;
import java.time.Duration;

public class TestApplication {

	WebDriver driver = null;
	ObjectReader or = null;
	BrowserImplementations bi = null;
	AccountCreationPage accountcreationpage = null;
	LandingPage landingpage = null;
	ExtentReports extent = null;
	ExtentTest test = null;
	TestUtilities testutilities = null;

	// Creating setup for test application which uses BeforeTest annotation
	@BeforeTest
	public void setUp() throws IOException {
		bi = new BrowserImplementations();
		driver = bi.getDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		or = new ObjectReader();
		landingpage = new LandingPage(driver);
		accountcreationpage = new AccountCreationPage(driver);

		testutilities = new TestUtilities();
		extent = new ExtentReports();
		test = extent.createTest("Create New Account Test");
		test.assignAuthor("Anuraj");
		ExtentSparkReporter spark = new ExtentSparkReporter("target/Spark.html");
		extent.attachReporter(spark);
		driver.get(or.getUrl());
		
	}

	// Clicking on create new account button
	// If we are not redirect to account creation page , Asserts return false
	// and failure is logged
	@Test(priority = 0)
	public void createNewAccountTest() throws IOException {
		String actUrl = landingpage.verifyUrl();
		String exUrl = or.getUrl();
		
		try {
		    Assert.assertTrue(actUrl.equals(exUrl), "Invalid landing page");
		    test.pass("Landing Page verification completed !");

		} catch (AssertionError e) {
			String path1 = testutilities.captureScreenshot(driver, "createAccountPage");
			test.addScreenCaptureFromPath(path1);
		    test.fail("Landing Page verification FAILED : " + e.getMessage());
		    extent.flush();
		    throw e; 
		}

		landingpage.createNewAccount();
		
		test.pass("Clicking create new account button Passed !!");
	}

	// Enter name
	@Test(priority = 1)
	public void enterNameTest() throws IOException, InterruptedException {

		accountcreationpage.enterName();
		test.pass("Entered Named successfully!");

	}

	// Enter surname
	@Test(priority = 2)
	public void enterSurnameTest() throws IOException, InterruptedException {
		accountcreationpage.enterSurname();
		test.pass("Entered surname successfully!");
	}

	// Day - match by text "27"
	@Test(priority = 3)
	public void enterDayTest() throws IOException, InterruptedException {
		accountcreationpage.enterDay();
		test.pass("Clicked Day successfully!");
	}

	// Month - open drop down, select correct Index of March
	@Test(priority = 4)
	public void enterMonthTest() throws IOException, InterruptedException {
		accountcreationpage.enterMonth();
		test.pass("Clicked Month successfully!");
	}

	// Year - open drop down, and find "2004" by text
	@Test(priority = 5)
	public void enterYearTest() throws IOException, InterruptedException {
		accountcreationpage.enterYear();
		test.pass("Clicked Year successfully!");
	}

	// Selecting Gender
	@Test(priority = 6)
	public void selectGenderTest() throws InterruptedException {
		accountcreationpage.enterGender();
		test.pass("Clicked Gender successfully!");
	}

	// Entering 9 digit mobile number
	@Test(priority = 7)
	public void enterNumberTest() throws InterruptedException {
		accountcreationpage.enterNumber();
		test.pass("Entered 9 digit number successfully !");
	}

	// keeping password field empty
	@Test(priority = 8)
	public void enterPasswordTest() {
		// password
		accountcreationpage.enterPassword();
		test.pass("keeping password field blank !");
	}

	// Clicking on submit button
	@Test(priority = 9)
	public void submitDetailsTest() throws InterruptedException {
		accountcreationpage.submitDetails();
		test.pass("Clicked on submit button successfully !");
	}

	// reading all the failure message and printing
	@Test(priority = 10)
	public void getErrorMessageTest() {
		accountcreationpage.errorMessage();
		test.pass("Identified error messages and printing them !!");
	}

	@AfterTest
	public void afterTest() {
		test.pass("Test has successfully completed !!");
		extent.flush();
		driver.quit();
	}
}