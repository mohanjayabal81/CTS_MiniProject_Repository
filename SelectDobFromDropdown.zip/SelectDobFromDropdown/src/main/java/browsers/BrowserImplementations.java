package browsers;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserImplementations {

	WebDriver driver = null;

	// Implementing two browsers
	public WebDriver getDriver() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		return driver;

	}

}
