package config;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ObjectReader {
	
	Properties po = null;
	FileInputStream fis = null;
	
	public ObjectReader() throws IOException {
		fis = new FileInputStream("C:\\Users\\2478731\\eclipse-workspace\\SelectDobFromDropdown\\ObjectRepository\\object.properties");
		po = new Properties();
		po.load(fis);
	}
	// getting data from object.properties file
	public String getBrowser() {
		return po.getProperty("browser");
	}
	
	public String getUrl() {
		return po.getProperty("baseUrl");
	}
	public String getName() {
		return po.getProperty("name");
	}
	public String getSurname() {
		return po.getProperty("surname");
	}
	public String getDay() {
		return po.getProperty("day");
	}
	public String getMonth() {
		return po.getProperty("month");
	}
	public String getYear() {
		return po.getProperty("year");
	}
	public String getMobileNumber() {
		return po.getProperty("mobileNumber");
	}
	public String getGender() {
		return po.getProperty("gender");
	}
}
