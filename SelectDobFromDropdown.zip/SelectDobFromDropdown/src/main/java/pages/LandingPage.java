package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LandingPage {
	WebDriver driver = null;
	
	
	public LandingPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String verifyUrl() {
		return driver.getCurrentUrl();
	}

	public void createNewAccount() {
		driver.findElement(By.linkText("Create new account")).click();
	}
}
