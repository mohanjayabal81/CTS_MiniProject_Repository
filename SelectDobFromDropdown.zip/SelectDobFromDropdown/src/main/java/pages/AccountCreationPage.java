package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import config.ObjectReader;
import utility.TestUtilities;

public class AccountCreationPage {
	ObjectReader or = null;
	WebDriver driver = null;
	TestUtilities testutilities = null;

	// Page elements
	private By nameXpath = By.xpath("//input[@id='_R_1cl2p4jikacppb6amH1_']");
	//private By nameXpath = By.id("_r_7_");
	private By surnameXpath = By.xpath("//input[@id='_R_1kl2p4jikacppb6amH1_']");
	// private By surnameXpath = By.id("_r_a_");
	private By dayXpath = By.xpath("//div[@aria-label='Select day']");
	private By monthXpath = By.xpath("//div[@aria-label='Select month']");
	private By yearXpath = By.xpath("//div[@aria-label='Select year']");
	private By genderXpath = By.xpath("//div[@role='combobox']");
	 private By numberId = By.xpath("//input[@id='_R_6ad8p4jikacppb6amH1_']");
	private By passwordXpath = By.xpath("//input[@id='_R_clap4jikacppb6amH1_']");
	// private By passwordXpath = By.id("_r_18_");
	private By submitXpath = By.xpath(
			"//div[@class='x1ja2u2z x78zum5 x2lah0s x1n2onr6 xl56j7k x6s0dn4 xozqiw3 x1q0g3np x972fbf x10w94by x1qhh985 x14e42zd x9f619 xtvsq51 xqbgfmv xbe3n85 x7a1id4 x1d9i5bo x1xila8y x1bumbmr xc8cyl1']//div[@class='html-div xdj266r xat24cr xexx8yu xyri2b x18d9i69 x1c1uobl x6s0dn4 x78zum5 xl56j7k x1e0frkt xf0ucvx xx2axb6']");
	private By roleXpath = By.xpath("//div[@role='option']");
	
	public AccountCreationPage(WebDriver driver) throws IOException {
		or = new ObjectReader();
		this.driver = driver;
		testutilities = new TestUtilities();
	}

	// Enter name
	public void enterName() {
		String username = or.getName();
		WebElement name = driver.findElement(nameXpath);
		name.sendKeys(username);

	}

	// Enter surname
	public void enterSurname() {
		String surName = or.getSurname();
		WebElement surname = driver.findElement(surnameXpath);
		surname.sendKeys(surName);
	}

	// Enter Day
	public void enterDay() {
	    String day = or.getDay();
	    driver.findElement(dayXpath).click();
	    List<WebElement> options = driver.findElements(roleXpath);
	    testutilities.selectFromDropdown(driver, options, day); 
	}

	// Enter Month
	public void enterMonth() {
	    String month = or.getMonth();
	    driver.findElement(monthXpath).click();
	    List<WebElement> options = driver.findElements(roleXpath);
	    testutilities.selectFromDropdown(driver, options, month); 
	}

	// Enter Year
	public void enterYear() {
	    String year = or.getYear();
	    driver.findElement(yearXpath).click();
	    List<WebElement> options = driver.findElements(roleXpath);
	    testutilities.selectFromDropdown(driver, options, year); 
	}

	public void enterGender() {

		// Step 1: Open Gender drop-down using combobox at index 3
		List<WebElement> comboboxes = driver.findElements(genderXpath);
		comboboxes.get(3).click();

		// Step 2: fetching the options after drop-down opens
		// (avoids StaleElementReferenceException)
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement genderOption = driver.findElements(roleXpath).get(195);
		js.executeScript("arguments[0].scrollIntoView(true);", genderOption);

		// Step 3: Re-fetching again just before clicking to avoid stale reference
		genderOption = driver.findElements(roleXpath).get(195);
		js.executeScript("arguments[0].click();", genderOption);

		System.out.println("Gender selected!");

	}

	// Enter 9 digit number
	public void enterNumber() {
		String number = or.getMobileNumber();
		driver.findElement(numberId).sendKeys(number);

	}

	// Keeping password field empty
	public void enterPassword() {
		driver.findElement(passwordXpath).click();

	}

	// Clicking on submit button
	public void submitDetails() {
		driver.findElement(submitXpath).click();
	}

	// printing all the failure messages
	public void errorMessage() {
		String phoneError = driver
				.findElement(By.xpath("//span[contains(text(),'Please enter a valid mobile number o')]")).getText();
		WebElement errorMsg = driver
				.findElement(By.xpath("//span[contains(text(),'Enter a combination of at least six numbers, lette')]"));
		String msg = errorMsg.getText();
		System.out.println(phoneError);
		System.out.println(msg);
	}
}
