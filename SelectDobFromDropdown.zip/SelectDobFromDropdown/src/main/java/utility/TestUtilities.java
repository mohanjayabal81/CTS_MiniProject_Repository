package utility;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TestUtilities {
	WebDriver driver = null;
	
	
	// Capturing screenshots
	public String captureScreenshot(WebDriver driver , String screenshotName) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		String path = System.getProperty("user.dir") + "/screenshots" + screenshotName + ".png";
		File dest = new File(path);
		FileUtils.copyFile(src,dest);
		
		return path;
	}
	
	
	public void selectFromDropdown(WebDriver driver, List<WebElement> options, String value) {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    
	    for (WebElement option : options) {
	        if (option.getText().trim().equals(value)) {
	            js.executeScript("arguments[0].scrollIntoView(true);", option);
	            js.executeScript("arguments[0].click();", option);
	            System.out.println("Selected: " + value);
	            break;
	        }
	    }
	}

	
}
