package utils;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusableMethods {

   WebDriver driver;
   WebDriverWait wait;
   ObjectReader u;
   
	
    public ReusableMethods(WebDriver driver){
        this.driver = driver;
        // Initialize the wait engine for 15 seconds
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.u = new ObjectReader();
    }
	
    public  void sub_Button() {
        // Wait for the submit button to be clickable before clicking
        try {
        	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("subbutton")))).click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}