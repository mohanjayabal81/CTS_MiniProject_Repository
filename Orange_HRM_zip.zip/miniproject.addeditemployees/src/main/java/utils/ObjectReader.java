package utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
public class ObjectReader {

	Properties p;
	public ObjectReader(){
	p = new Properties();
	FileInputStream fis = null;
	try {
		fis = new FileInputStream("C:\\Users\\2478499\\eclipse-workspace\\miniproject.addeditemployees\\ObjectRepository\\Object.properties");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		p.load(fis);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	
	//add comments
	
    public String getLocator(String key){
        return p.getProperty(key);
    }
	public String geturl() {
		return p.getProperty("BaseUrl");
	}
	
	
}
