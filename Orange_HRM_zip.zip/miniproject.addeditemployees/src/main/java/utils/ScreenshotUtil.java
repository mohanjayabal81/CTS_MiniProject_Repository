package utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotUtil {

    // Method to capture the entire browser window
    public static String capturePage(WebDriver driver, String fileName) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String name = fileName + "_" + timestamp + ".png";
        String destination = "reports/screenshots/" + name;

        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(src, new File(destination));
        } catch (IOException e) {
            System.err.println("Failed to capture page screenshot: " + e.getMessage());
        }
        
        // Returns the relative path for Extent Reports
        return "screenshots/" + name;
    }

    // Method to capture only a specific element (useful for highlighting errors)
    public static String captureElement(WebElement element, String elementName) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String name = "ERR_" + elementName + "_" + timestamp + ".png";
        String destination = "screenshots/" + name;

        File src = element.getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(src, new File(destination));
        } catch (IOException e) {
            System.err.println("Failed to capture element screenshot: " + e.getMessage());
        }
        
        return "screenshots/" + name;
    }
}