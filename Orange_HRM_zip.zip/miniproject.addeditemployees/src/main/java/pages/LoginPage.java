package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.ObjectReader;
import utils.ReusableMethods;

public class LoginPage {
    WebDriver driver;
    WebDriverWait wait;
    ObjectReader u;
    ReusableMethods rm;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.u = new ObjectReader();
        this.rm = new ReusableMethods(driver);
    }

	public void login(String user, String pass) {
        try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("username")))).sendKeys(user);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("password")))).sendKeys(pass);
			rm.sub_Button();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}