package pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.ObjectReader;
import utils.ReusableMethods;

public class AddEmpPage {
    WebDriver driver;
    WebDriverWait wait;
    ObjectReader u;
    ReusableMethods rm;

    public AddEmpPage(WebDriver driver) {
        this.driver = driver;
        // Global explicit wait set to 15 seconds
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.u = new ObjectReader();
        this.rm = new ReusableMethods(driver);
    }

    /**
     * Scenario: Add New Employee
     */
    public void addEmployee(String fName, String lName, String empid, String user, String pwd) {
        try {
            // Wait for names to be visible before typing
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("firstName")))).sendKeys(fName);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("lastName")))).sendKeys(lName);

            // Clear predefined value from the empid field
            WebElement empIdField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("empid"))));
            empIdField.sendKeys(Keys.CONTROL + "a");
            empIdField.sendKeys(Keys.BACK_SPACE);
            empIdField.sendKeys(empid);

            // CRITICAL: Wait for any invisible loading overlays to disappear before clicking toggle
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("oxd-form-loader")));

            // Click the toggle switch to enable login details
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("toggle")))).click();

            // Wait for login detail fields to appear after toggle
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("userName")))).sendKeys(user);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("passwordField")))).sendKeys(pwd);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("confirmPassword")))).sendKeys(pwd);
            
            rm.sub_Button();
            
            // SYNC POINT: Wait for the URL to change to 'viewPersonalDetails' to ensure record is saved
            wait.until(ExpectedConditions.urlContains("viewPersonalDetails"));

        } catch (Exception e) {
            System.err.println("Error in addEmployee: " + e.getMessage());
            // Rethrow so the TestMain utility captures the screenshot on failure
            throw e; 
        }
    }

    /**
     * Scenario: Edit Personal Details
     */
 
        
        
        
        public void editPersonalDetails() {
            try {
                // 1. Ensure we have transitioned to the Personal Details page
                wait.until(ExpectedConditions.urlContains("viewPersonalDetails"));

                // 2. CRITICAL FIX: Wait for the loading spinner to disappear
                // This prevents the "ElementClickInterceptedException" you just received
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("oxd-form-loader")));

                // 3. Now interact with the Nationality dropdown
                WebElement nationality = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("nationality"))));
                nationality.click();
                
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("indian")))).click();

                // 4. Select Marital Status
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("marital")))).click();
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("single")))).click();

                // 5. Select Gender
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("male")))).click();

                // Final Save
                rm.sub_Button();
                
                // Wait for the success toaster to appear
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("oxd-toaster_1")));

            } catch (Exception e) {
                System.err.println("Error in editPersonalDetails: " + e.getMessage());
                // Rethrow so the Extent Report captures the screenshot of the failure
                throw e; 
            }
        }
    }
