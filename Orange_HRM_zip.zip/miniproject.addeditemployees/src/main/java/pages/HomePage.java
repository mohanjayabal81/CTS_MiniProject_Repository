package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.ObjectReader;

public class HomePage {
    WebDriver driver;
    WebDriverWait wait;
    ObjectReader u;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.u = new ObjectReader();
    }

    public void goToAddEmp() {
        try {
        	
        	//navigating to PIM module 
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("pim")))).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("addEmployee")))).click();
        } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    
    public void logout() {
        try {
            // Step 1: Click the user profile dropdown
          wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("profile")))).click();
            // Step 2: Click the Logout link
          wait.until(ExpectedConditions.elementToBeClickable(By.xpath(u.getLocator("logout")))).click();
     
            System.out.println("Logout performed successfully.");
        } catch (Exception e) {
            System.err.println("Logout failed: " + e.getMessage());
        }
    }
    
    public boolean isDashboardVisible() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(u.getLocator("profile")))).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}