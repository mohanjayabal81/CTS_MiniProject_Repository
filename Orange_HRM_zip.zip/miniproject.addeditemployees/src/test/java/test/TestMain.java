package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import browserImplementation.BrowserConfig;
import pages.*;
import utils.ObjectReader;
import utils.ReusableMethods;
import utils.ScreenshotUtil;
import java.time.Duration;

public class TestMain {
    // --- TEST DATA ---
    private static final String ADMIN_USER = "Admin";
    private static final String ADMIN_PASS = "admin123";
    private static final String EMP_ID = "2098110" + (System.currentTimeMillis() % 1000);
    private static final String FIRST_NAME = "Kamuuu";
    private static final String LAST_NAME = "Sai";
    private static final String NEW_EMP_USER = "user_" + (System.currentTimeMillis() % 10000);
    private static final String NEW_EMP_PASS = "Password123!";

    // --- DRIVER & PAGES ---
    WebDriver driver;
    LoginPage lp;
    HomePage hp;
    AddEmpPage ap;
    ObjectReader u;
    BrowserConfig bc;
    ReusableMethods rm;

    // --- EXTENT REPORTS ---
    ExtentReports extent;
    ExtentSparkReporter spark;
    ExtentTest test;

    @BeforeSuite
    public void setUp() {
        // Report Setup
        spark = new ExtentSparkReporter("reports/OrangeHRM_ExecutionReport.html");
        spark.config().setDocumentTitle("OrangeHRM Automation Report");
        spark.config().setReportName("End-to-End HR Workflow");

        extent = new ExtentReports();
        extent.attachReporter(spark);

        // Initialization
        bc = new BrowserConfig();
        driver = bc.chooseBrowser();
        u = new ObjectReader();
        lp = new LoginPage(driver);
        hp = new HomePage(driver);
        ap = new AddEmpPage(driver);
        
        driver.manage().window().maximize();
    }

    public WebDriver getDriver() {
        return this.driver;
    }

    @Test(priority = 1)
    public void testLogin() {
        test = extent.createTest("Scenario 1: System Authentication");
        SoftAssert softAssert = new SoftAssert();
        
        try {
            driver.get(u.geturl());
            lp.login(ADMIN_USER, ADMIN_PASS);
            
            // Wait for dashboard to be visible before taking the screenshot
            boolean isVisible = hp.isDashboardVisible();
            test.addScreenCaptureFromPath(ScreenshotUtil.capturePage(driver, "Login_Success"));
            
            softAssert.assertTrue(isVisible, "Login failed - Profile dropdown not visible.");
            test.pass("Successfully authenticated as Admin.");
        } catch (Exception e) {
            WebElement loginBtn = driver.findElement(By.xpath(u.getLocator("subbutton")));
            test.fail("Login Step Failed: " + e.getMessage());
            test.addScreenCaptureFromPath(ScreenshotUtil.captureElement(loginBtn, "LoginButton_Error"));
            throw e; // Fail the test immediately
        }
        softAssert.assertAll();
    }

    @Test(priority = 2, dependsOnMethods = "testLogin")
    public void testAddEmployee() throws Exception {
        test = extent.createTest("Scenario 2: Employee Record Creation");
        SoftAssert softAssert = new SoftAssert();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        
        try {
            hp.goToAddEmp();
            ap.addEmployee(FIRST_NAME, LAST_NAME, EMP_ID, NEW_EMP_USER, NEW_EMP_PASS);
            
            // FIX for White Screenshot: Wait for loader to vanish and URL to update
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("oxd-form-loader")));
            wait.until(ExpectedConditions.urlContains("viewPersonalDetails"));
            Thread.sleep(2000);
           // driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
            
            
            test.addScreenCaptureFromPath(ScreenshotUtil.capturePage(driver, "AddEmployee_Data_Saved"));
            
            softAssert.assertTrue(driver.getCurrentUrl().contains("viewPersonalDetails"), "Failed to redirect to Personal Details page.");
            test.pass("Employee record " + EMP_ID + " submitted and verified.");
        } catch (Exception e) {
            WebElement saveBtn = driver.findElement(By.xpath(u.getLocator("subbutton")));
            test.fail("Creation Failed: " + e.getMessage());
            test.addScreenCaptureFromPath(ScreenshotUtil.captureElement(saveBtn, "SaveButton_Error"));
            throw e; // Ensures dependent tests (Step 3) are skipped
        }
        softAssert.assertAll();
    }

    @Test(priority = 3, dependsOnMethods = "testAddEmployee")
    public void testEditAndLogout() {
        test = extent.createTest("Scenario 3: Profile Update and Secure Logout");
        SoftAssert softAssert = new SoftAssert();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        
        try {
            // 1. Perform Updates (Nationality, Gender, Marital Status)
            ap.editPersonalDetails();
            
            // 2. Wait for the loading spinner to vanish to avoid "White Screenshots"
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("oxd-form-loader")));
            
            // 3. Take screenshot of the updated details
            test.addScreenCaptureFromPath(ScreenshotUtil.capturePage(driver, "PersonalDetails_Updated"));
            
            // 4. Perform Logout
            hp.logout();
            
            // 5. Explicitly verify redirection to the Login page
            boolean isLoggedOut = wait.until(ExpectedConditions.urlContains("login"));
            softAssert.assertTrue(isLoggedOut, "Final Validation: Failed to redirect to Login page after logout.");
            
            test.pass("Details updated successfully and session terminated securely.");
            
        } catch (Exception e) {
            // Log the specific exception to the Extent Report
            test.log(Status.FAIL, "Update/Logout Error: " + e.getMessage());
            test.addScreenCaptureFromPath(ScreenshotUtil.capturePage(driver, "Session_Error"));
            
            // Rethrow so TestNG and the report mark it as a hard failure
            throw e;
        } finally {
            // Ensure all soft assertions are collected if the try block finished
            softAssert.assertAll();
        }
    }

    @AfterSuite
    public void tearDown() {
        if (bc != null) { bc.closeBrowser(); }
        if (extent != null) { extent.flush(); }
    }
}