package testcases;

import java.io.IOException;
import java.time.Duration;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.ApplyFilters;
import pages.Booking;
import pages.CountResult;
import pages.SearchItem;
import pages.SearchPage;
import pages.SortItems;
import pages.landingpage;
import utility.ObjectReader;
import utility.utility;
import webDrivers.driversetup;

public class newTest {
		
	ObjectReader reader;
	landingpage lp;
	WebDriver driver;
	driversetup setup;
	SearchPage search;
	SearchItem item;
	Booking book;
	ApplyFilters filters;
	utility util;
	SortItems sortitems;
	CountResult countresult;
	
	
	@BeforeClass
	public void createDriver() throws IOException {
		setup = new driversetup();
		reader=new ObjectReader();
		driver=setup.launchChrome();
		driver.get(reader.baseUrl());
		lp=new landingpage(driver);
	}
	
	@Test(priority=1)
	public void titleVerification(){
		try {
		driver.manage().window().maximize();
		String actTitle=lp.actualLandingPageTitle();
		String expTitle=reader.getLandingPageTitle().trim();
		Assert.assertEquals(actTitle, expTitle,"Not Matched");
		
		Reporter.log("Landing page loaded successfully");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	@Test(dependsOnMethods="titleVerification")
	public void handlePopup() {
		try {
		search=new SearchPage(driver);
		
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			WebElement closeBtn = wait.until(ExpectedConditions.elementToBeClickable(By.className("notification-banner__section-close")));
			closeBtn.click();
//			System.out.println("Random popup detected and closed.");

			Assert.assertTrue(wait.until(ExpectedConditions.invisibilityOf(closeBtn)),"Popup was not closed successfully");
			Reporter.log("Random popup detected and closed",true);
			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Popup was not closed successfully",true);
		}
		
	}
	
	@Test(dependsOnMethods="handlePopup")
	public void searchButtonValidation(){
		try {
		search=new SearchPage(driver);
		reader=new ObjectReader();
		
		// 1. Create the Wait object (e.g., 10 seconds timeout)
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// 2. Use elementToBeClickable
		WebElement submitBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(reader.getSearchButtonLocation())));

		// 3. Now you can safely click
		submitBtn.click();
		

		 Assert.assertTrue(
		        driver.getCurrentUrl().contains("search"),
		        "Search button did not navigate to search page"
		    );

		
		Reporter.log("Search button validated successfully",true);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Search button did not navigate to search page",true);
		}
	}
	
	


	
	@Test(dependsOnMethods="searchButtonValidation")
	public void searchItem()  {
		try {
		item=new SearchItem(driver);
		reader=new ObjectReader();
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement box=item.getSearchBoxLocation();
		wait.until(ExpectedConditions.visibilityOf(box));
		String searchtext=item.getSearchItem();
		box.sendKeys(searchtext);
		
		WebElement btn=wait.until(ExpectedConditions.elementToBeClickable(item.getSearchButton()));
		btn.click();
		
		
		Reporter.log("Searched item successfully",true);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Search results are not displayed for searched item",true);
		}
		
	}
	
	@Test(dependsOnMethods="searchItem")
	public void selectSearchResult(){
		try {
		item=new SearchItem(driver);
		reader=new ObjectReader();
		Thread.sleep(2000);
		
		WebElement result=item.selectSearchResult();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", result);
		
		
		

		result.click();

		 Assert.assertTrue(
		        driver.getCurrentUrl().contains("cruise"),
		        "Search result did not open cruise detail page"
		    );
		 Reporter.log("Search result opened the cruise detail page",true);

		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Search result did not open cruise detail page",true);
		}
	}
	
	@Test(dependsOnMethods="selectSearchResult")
	public void clickShopNowButton(){
		try {
		book=new Booking(driver);
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
		
		WebElement clickshopbtn=wait.until(ExpectedConditions.elementToBeClickable(book.getShopButtonLocation()));
				clickshopbtn.click();
				

		Assert.assertTrue(
				 driver.getCurrentUrl().contains("USA"),
				        "Shop Now button did not redirect to listing page"
				    );
		Reporter.log("Shop Now button redirect to listing page",true);
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Shop Now button did not redirect to listing page",true);
		}
		
	}
	
	@Test(dependsOnMethods="clickShopNowButton")
	public void applyFilters() {
		try {
		filters=new ApplyFilters(driver);
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement clickbtn= wait.until(ExpectedConditions.elementToBeClickable(filters.getCruiseDatesButton()));
		clickbtn.click();
//		System.out.println("clicked");
		Thread.sleep(3000);
		


		 Reporter.log("Cruise date filter model opened",true);

		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Cruise date filter modal did not open",true);
		}
		
		
	}
	
	@Test(dependsOnMethods="applyFilters")
	public void selectNextFourMonths() {
		try {
		filters=new ApplyFilters(driver);
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		
		Thread.sleep(3000);
		List<WebElement> allMonths=filters.getMonthsList();
		int selected=0;
		for(int i=0;i<allMonths.size();i++) {
			WebElement month=allMonths.get(i);
			
			//check if the month is enabled
			if(month.isEnabled()) {
			JavascriptExecutor js=(JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView(true);arguments[0].click()", month);
			selected+=1;
			if(selected==4) {
				break;
				}
			}
		}
		filters.getApplyButton().click();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	@Test(dependsOnMethods="selectNextFourMonths")
	public void selectDepartureport() {
		try {
		filters=new ApplyFilters(driver);
		util= new utility();
		
		util.scrollAndClick(driver, filters.getDepatureport());
		util.scrollAndClick(driver, filters.getClickDepatureport());
		
//		System.out.println("Depature port is selected");

		  Assert.assertTrue(
		        filters.getDepatureport().isDisplayed(),
		        "Departure port was not selected"
		    );
		  Reporter.log("Depature port is selected",true);

		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Depature port is selected",true);
		}
		
		
	}
	@Test(dependsOnMethods="selectDepartureport")
	public void selectDestination(){
		try {
		filters=new ApplyFilters(driver);
		util=new utility();
		util.scrollAndClick(driver, filters.getDestinationSite());	
		util.scrollAndClick(driver, filters.getDestinationSiteClick());
		Thread.sleep(3000);
		
		
		

		Assert.assertTrue(
		        filters.getDestinationSite().isDisplayed(),
		        "Destination filter was not applied"
		    );
		Reporter.log("Destination is selected",true);

		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Destination filter was not applied",true);
			}
		}
	
	
	@Test(dependsOnMethods="selectDestination")
	public void  numberOfNights() {
		try {
		filters=new ApplyFilters(driver);
		util=new utility();
		util.scrollAndClick(driver,filters.getNoOfNights());
		util.scrollAndClick(driver,filters.getNoOfNightsClick() );
		Thread.sleep(3000);
		


		  	Reporter.log("Number of nights filter selected",true);
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Number of nights filter not selected",true);
		}
	}
	
	@Test(dependsOnMethods="numberOfNights")
	public void clickApply(){
		try {
		filters=new ApplyFilters(driver);
		filters.getApply().click();
		Thread.sleep(3000);
		
		   Assert.assertTrue(
		        driver.getPageSource().contains("cruise"),
		        "Results did not refresh after applying filters"
		    );
		   Reporter.log("Results refresh after applying filters",true);
		   
		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Results did not refresh after applying filters",true);
		}
	}
	
	@Test(dependsOnMethods="clickApply")
	public void SortIteams()  {
		try {
		sortitems=new SortItems(driver);
		WebElement sortbtn=sortitems.SortDropdown();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(sortbtn));
		sortbtn.click();
		WebElement low_to_high=sortitems.Sortitem();
		
		wait.until(ExpectedConditions.elementToBeClickable(low_to_high));
		low_to_high.click();
		
		 Assert.assertTrue(
		        sortitems.SortDropdown().getText().toLowerCase().contains("low"),
		        "Items were not sorted low to high"
		    );
		 Reporter.log("Item is sorted low to high",true);

		}catch(Exception e){
			System.out.println(e.getMessage());
			Reporter.log("Items were not sorted low to high",true);
		}
	}
	
		
	@Test(dependsOnMethods="SortIteams")
	public void CountTheCruise(){
		try {
		countresult=new CountResult(driver);
		Thread.sleep(3000);
		String res=countresult.CountTheCruise().getText();
		System.out.println(res);

		 Reporter.log("Cruise count after applly filters",true);

		System.out.println("Total number of Cruies"+res);
		}catch(Exception e) {
			System.out.println(e.getMessage());
			Reporter.log("Cruise count is zero after applying filters",true);
		}
		
	}
	

	
	@AfterClass
	public void closeDriver() {
		driver.quit();
	}
}
