package webDrivers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class driversetup {
	private WebDriver driver;
	public WebDriver getDriver() {
		return driver;
	}
		
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
	//Initializing the chrome browser
	public WebDriver launchChrome() {
		driver= new ChromeDriver();
		
		return driver;
	}
	
	//initializing the Edge browser
	public WebDriver launchEdge() {
		driver=new EdgeDriver();
		return driver;
	}
}
