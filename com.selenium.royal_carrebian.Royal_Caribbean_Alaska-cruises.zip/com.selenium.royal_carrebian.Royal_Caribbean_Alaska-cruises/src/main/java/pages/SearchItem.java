package pages;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.ObjectReader;

public class SearchItem {
		WebDriver driver;
		ObjectReader reader;
		
	public SearchItem(WebDriver driver) throws IOException {
		this.driver=driver;
		reader=new ObjectReader();
	}
	
	public String getSearchItem() throws IOException {
		return reader.getSearchItem();
	}




	
	public WebElement getSearchBoxLocation() {
	
		WebElement searchbox=driver.findElement(By.xpath(reader.getSearchBoxLocation()));
		return searchbox;
	}
	
	public WebElement selectSearchResult() {
		
		WebElement searchresult=driver.findElement(By.xpath(reader.getSearchResult()));
		return searchresult;
		
	}
	
	public WebElement getSearchButton() {
		WebElement searchbutton=driver.findElement(By.xpath(reader.getSearchButton()));
		return searchbutton;
	}
	
	
}
