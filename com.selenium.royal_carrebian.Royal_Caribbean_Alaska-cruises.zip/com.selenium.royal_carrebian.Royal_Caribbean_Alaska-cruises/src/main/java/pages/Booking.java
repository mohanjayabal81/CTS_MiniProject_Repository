package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.ObjectReader;

public class Booking {
		WebDriver driver;
		ObjectReader reader;
		
		public Booking(WebDriver driver) throws IOException {
			this.driver=driver;
			reader=new ObjectReader();
		}
		
		public WebElement getShopButtonLocation() {
			WebElement shopBtn=driver.findElement(By.xpath(reader.getShopNowButtonLocation()));
			return shopBtn;
		}
		
		
}
