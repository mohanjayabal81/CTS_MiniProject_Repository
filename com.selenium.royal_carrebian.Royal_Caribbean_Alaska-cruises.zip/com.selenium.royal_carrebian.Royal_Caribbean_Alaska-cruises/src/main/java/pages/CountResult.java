package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.ObjectReader;

public class CountResult {
	WebDriver driver;
	ObjectReader reader;
	
	public CountResult(WebDriver driver) throws IOException{
		this.driver=driver;
		reader=new ObjectReader();
		
	}
	
	public WebElement CountTheCruise() {
		WebElement count=driver.findElement(By.xpath(reader.getCount()));
		return count;
	}
	
}
