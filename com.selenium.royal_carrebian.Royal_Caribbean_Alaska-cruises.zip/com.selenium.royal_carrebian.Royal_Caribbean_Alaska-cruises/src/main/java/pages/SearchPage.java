package pages;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utility.ObjectReader;

public class SearchPage {
		WebDriver driver;
		ObjectReader reader;
		
		public SearchPage(WebDriver driver) {
			this.driver=driver;
		}
		
		public WebElement handlePopUpNotification() {
			WebElement popup=driver.findElement(By.className("notification-banner__section-close"));
			return popup;
		}
		
		
		
		
		public String searchButtonVerification() throws IOException {
			reader=new ObjectReader();
			WebElement searchBtn=driver.findElement(By.xpath(reader.getSearchButtonLocation()));
			System.out.println(searchBtn.getText());
			return searchBtn.getText();
		}
		
}
