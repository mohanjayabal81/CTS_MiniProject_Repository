package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.ObjectReader;

public class ApplyFilters {
	WebDriver driver;
	ObjectReader reader;
	public ApplyFilters(WebDriver driver) throws IOException {
		this.driver=driver;
		reader=new ObjectReader();
	}
	
	public WebElement getCruiseDatesButton() {
		WebElement cruise_date=driver.findElement(By.xpath(reader.getCruiseFilterButtonLocation()));
		return cruise_date;
	}
	public List<WebElement> getMonthsList() {
		List<WebElement> monthsList=driver.findElements(By.xpath(reader.getMonthsListLocation()));
		return monthsList;
	}
	public WebElement getApplyButton() {
		WebElement applynowBtn=driver.findElement(By.xpath(reader.getApplyNowButton()));
		return applynowBtn;
	}
	
	public WebElement getDepatureport() {
		WebElement depatureport=driver.findElement(By.cssSelector(reader.getdepartureport()));
		return depatureport;
	}
	public WebElement getClickDepatureport() {
		WebElement clickdepatureport=driver.findElement(By.cssSelector(reader.getclickDepartureport()));
		return clickdepatureport;
	}
	

	public WebElement getDestinationSite() {
		// TODO Auto-generated method stub
		WebElement destination=driver.findElement(By.cssSelector(reader.getDestination()));
		return destination;
		
	}

	public WebElement getDestinationSiteClick() {
		// TODO Auto-generated method stub
		WebElement destinationClick=driver.findElement(By.cssSelector(reader.getDestinationClick()));
		return destinationClick;
		
	}
	
	public WebElement getNoOfNights() {
		WebElement nights=driver.findElement(By.cssSelector(reader.getNoOfNights()));
		return nights;
	}
	 public WebElement getNoOfNightsClick() {
		 WebElement nightsClick=driver.findElement(By.xpath(reader.getNightsClick()));
		 return nightsClick;
	 }
	
	 public WebElement getApply() {
		 WebElement apply=driver.findElement(By.xpath(reader.getApply()));
		 return apply;
	 }
}
