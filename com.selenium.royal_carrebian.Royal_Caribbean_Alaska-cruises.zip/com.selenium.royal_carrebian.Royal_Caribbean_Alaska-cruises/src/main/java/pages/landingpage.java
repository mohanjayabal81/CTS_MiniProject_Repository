package pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;


import utility.ObjectReader;

public class landingpage {
		private WebDriver driver;
		ObjectReader obj;
		public landingpage(WebDriver driver) throws IOException {
			this.driver=driver;
			obj=new ObjectReader();
		}
		
		//verify Landing page
		public String actualLandingPageTitle() throws IOException {
			String actTitle=driver.getTitle();
			return actTitle;
		}
}
