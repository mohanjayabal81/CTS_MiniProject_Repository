package pages;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.ObjectReader;

public class SortItems {
	WebDriver driver;
	ObjectReader reader;
	
	public  SortItems(WebDriver driver) throws IOException {
		this.driver=driver;
		reader=new ObjectReader();
	}
	
	
	public WebElement SortDropdown() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		 WebElement sortDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(reader.getSortDropdown())));
		        
		 return sortDropdown;

	}
	public WebElement Sortitem() {
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement sortOption = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.xpath(reader.getSortIteams())
                )
        );
		return sortOption;

	}
	
	

}
