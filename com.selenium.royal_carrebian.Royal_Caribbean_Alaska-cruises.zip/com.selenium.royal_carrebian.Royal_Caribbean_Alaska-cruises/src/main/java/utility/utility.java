package utility;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class utility {
	
	public void scrollAndClick(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		int scrollAttempts = 0;
		boolean isElementFound = false;

		// Scroll Down
		while (!isElementFound && scrollAttempts < 10) {
			try {
				if (element.isEnabled()) {
					isElementFound = true;
					break;
				}
			} catch (NoSuchElementException e) {
				js.executeScript("window.scrollBy(0, 250)");
				scrollAttempts++;
			}
		}

		// Scroll Up if not found
		if (!isElementFound) {
			scrollAttempts = 0;
			while (!isElementFound && scrollAttempts < 10) {
				try {
					if (element.isDisplayed()) {
						isElementFound = true;
						break;
					}
				} catch (NoSuchElementException e) {
					js.executeScript("window.scrollBy(0, -250)");
					scrollAttempts++;
				}
			}
		}
		// Click the element if found using JavaScript
		if (isElementFound) {
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			js.executeScript("arguments[0].click();", element);
		} else {
			System.out.println("Element not found after scrolling.");
		}
	}
	
}
