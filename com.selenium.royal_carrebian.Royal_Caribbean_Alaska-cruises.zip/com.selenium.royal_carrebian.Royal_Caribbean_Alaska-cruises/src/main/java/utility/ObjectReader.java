package utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ObjectReader {
	private Properties pro;

	public Properties getPro() {
		return pro;
	}

	public void setPro(Properties pro) {
		this.pro = pro;
	}
	
	//Loading the object.properties file
	public ObjectReader() throws IOException {
		pro=new Properties();
		FileInputStream fs=new FileInputStream("C:\\Users\\2479995\\Downloads\\mini\\com.selenium.royal_carrebian.Royal_Caribbean_Alaska-cruises\\src\\main\\resources\\objectRepository\\object.properties");
		pro.load(fs);
	}
	
	public String baseUrl() {
		return pro.getProperty("baseUrl");
	}
	
	public String getLandingPageTitle() {
		return pro.getProperty("homePageTitle");
	}
	
	public String getActualPageTitle() {
		return pro.getProperty("titleLocator");
	}
	
	public String getSearchButtonLocation() {
		return pro.getProperty("searchLocator");
	}
	public String getSearchButton() {
		return pro.getProperty("searchbutton");
	}
	
	public String getSearchItem() {
		return pro.getProperty("searchItem");
	}
	
	public String getSearchBoxLocation() {
		return pro.getProperty("searchBoxPath");
	}
	
	public String getSearchResult() {
		return pro.getProperty("searchresult");
	}
	
	
	public String getShopNowButtonLocation() {
		return pro.getProperty("shopnow_button");
	}
	
	public String getCruiseFilterButtonLocation() {
		return pro.getProperty("crusie_button");
	}
	
	public String getMonthsListLocation() {
		return pro.getProperty("month_list");
	}
	
	public String getApplyNowButton() {
		return pro.getProperty("applyNow_button");
	}
	public String getdepartureport() {
		return pro.getProperty("Depatureport");
	}
	public String getclickDepartureport() {
		return pro.getProperty("clickDepartureport");
	}
	

	public String getDestination() {
		return pro.getProperty("destination");	
	}

	public String getDestinationClick() {
		return pro.getProperty("clickdestination");
	}
	
	public String getNoOfNights() {
		return pro.getProperty("NoOfNights");
	}
	public String getNightsClick() {
		return pro.getProperty("NightsClick");
	}
	
	public String getApply() {
		return pro.getProperty("apply");
	}
	public String getSortDropdown() {
		return pro.getProperty("sortdropdown");
	}
	public String getSortIteams() {
		return pro.getProperty("sortitem");
	}
	
	public String getCount() {
		return pro.getProperty("countitems");
	}
}
